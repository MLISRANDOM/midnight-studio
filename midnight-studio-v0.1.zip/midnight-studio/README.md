# Midnight Studio (phone-only, $0 base mode)

Mobile-first **animated motion-comic studio**. No installation, paid API, backend or GPU needed for built-in features. It is **not yet an AI image/video synthesis engine**. It makes scene plans, narration scripts, prompts, stylized animated backgrounds, and supports manually importing AI-generated illustrations. Browser video recording depends on your browser's support and may fail on iOS.

## What works in v0.1
- Prompt/premise to editable beat-based storyboard (template-driven, not LLM)
- Consistent character look in prompts; shot, camera movement, setting, narration, timings
- Editable scene timeline, up/down/reorder, delete/add
- Frame-by-frame canvas preview, simple 2D silhouette and parallax motion
- Upload custom artwork per scene from Photos/Files (in memory until tab closes)
- Download AI image prompts (.txt), project JSON and snapshot (.png)
- Browser video export via Canvas capture + MediaRecorder **only if supported** (no audio)
- Phone-friendly interface; localStorage autosave (except uploaded images)

## Deploy free with GitHub Pages using only an iPhone
1. In Safari, sign into GitHub and create a new **public** repository named `midnight-studio` (GitHub's repo creation is not available in the currently connected ChatGPT GitHub actions).
2. Upload `index.html` and `README.md` at the repository root using GitHub's **Add file > Upload files**.
3. In repository **Settings > Pages**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
4. Open `https://YOUR-USERNAME.github.io/midnight-studio/` in Safari. If supported, use Safari Share > Add to Home Screen.

You can also download the ZIP and open `index.html` with a phone-capable static web host. Safari may restrict local HTML file features; hosted HTTPS is recommended.

## What $0 realistically means
GitHub Pages can host static public projects at no cost on GitHub Free. It is not a GPU video synthesis service. Third-party free community video generators may have queues, quotas, content restrictions and downtime, and must not be used as an assumed unlimited backend. This MVP deliberately avoids integrating an insecure public proxy or embedding API credentials in HTML. AI video synthesis, voice recording, automatic subtitles, and full-frame character animation are **not implemented yet**.

## Data and privacy
The app runs client-side. Local drafts persist using localStorage; imported art is not persisted due to browser quota. Do not upload secrets or private photos to public AI demos unless you consent to the service's terms. Export your JSON often.

## License
MIT. See LICENSE.
